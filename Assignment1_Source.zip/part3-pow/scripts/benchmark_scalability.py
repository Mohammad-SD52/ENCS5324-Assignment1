import csv
import hashlib
import json
import os
import signal
import subprocess
import time
import urllib.request
from pathlib import Path

BASE = "http://127.0.0.1:8080"
DATA = "ads-benchmark-2026"
DIFFICULTY = 5
COUNTS = [1, 2, 4, 8]
TRIALS = 5

ROOT = Path.cwd()
OUT = ROOT / "evidence" / "scalability"
OUT.mkdir(parents=True, exist_ok=True)

def api(path, payload=None):
    body = json.dumps(payload).encode() if payload is not None else None
    request = urllib.request.Request(
        BASE + path,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST" if payload is not None else "GET"
    )
    with urllib.request.urlopen(request, timeout=10) as response:
        return json.load(response)

def wait_for_workers(count):
    deadline = time.monotonic() + 30
    while time.monotonic() < deadline:
        try:
            workers = api("/workers")
            alive = [w for w in workers if w["alive"]]
            if len(alive) == count:
                return
        except Exception:
            pass
        time.sleep(0.2)
    raise RuntimeError("Workers did not register")

def launch(command, logfile):
    handle = open(OUT / logfile, "w")
    process = subprocess.Popen(
        command,
        stdout=handle,
        stderr=subprocess.STDOUT,
        start_new_session=True
    )
    handle.close()
    return process

def stop_all(processes):
    for process in reversed(processes):
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGINT)

    for process in reversed(processes):
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()

def execute_job():
    created = api("/jobs", {
        "data": DATA,
        "difficulty": DIFFICULTY
    })
    job_id = created["job_id"]
    deadline = time.monotonic() + 120

    while time.monotonic() < deadline:
        job = api("/jobs/" + job_id)

        if job["status"] == "FOUND":
            nonce = job["nonce"]
            expected = hashlib.sha256(
                (DATA + str(nonce)).encode()
            ).hexdigest()

            if expected != job["hash"] or not expected.startswith("0" * DIFFICULTY):
                raise RuntimeError("SHA-256 verification failed")

            return job

        if job["status"] != "RUNNING":
            raise RuntimeError("Unexpected status: " + job["status"])

        time.sleep(0.02)

    raise TimeoutError("Job exceeded 120 seconds")

results = []

print("===== SCALABILITY BENCHMARK =====", flush=True)
print(f"Difficulty={DIFFICULTY}, Data={DATA}")
print(f"Trials per worker count={TRIALS}\n", flush=True)

for count in COUNTS:
    processes = []
    print(f"===== {count} WORKERS =====", flush=True)

    try:
        processes.append(launch([
            str(ROOT / "bin" / "ads-coordinator"),
            "-http=127.0.0.1:8080",
            "-grpc=127.0.0.1:50052",
            f"-workers={count}",
            "-range-size=200000",
            "-progress-interval=50000",
            "-range-timeout=120s"
        ], f"coordinator_{count}.log"))

        for i in range(1, count + 1):
            processes.append(launch([
                str(ROOT / "bin" / "ads-worker"),
                f"-id=w{i}",
                f"-listen=127.0.0.1:{50060+i}",
                "-coordinator=127.0.0.1:50052",
                "-heartbeat=2s"
            ], f"worker_{count}_w{i}.log"))

        wait_for_workers(count)

        times = []
        for trial in range(1, TRIALS + 1):
            job = execute_job()
            elapsed = job["elapsed_seconds"]
            times.append(elapsed)
            print(
                f"Trial {trial}: {elapsed:.6f}s "
                f"| nonce={job['nonce']} | VERIFIED",
                flush=True
            )

        average = sum(times) / len(times)
        results.append((count, average, min(times), max(times)))
        print(f"Average: {average:.6f}s\n", flush=True)

    finally:
        stop_all(processes)
        time.sleep(1)

baseline = results[0][1]

with open(OUT / "results.csv", "w", newline="") as file:
    writer = csv.writer(file)
    writer.writerow([
        "workers", "avg_seconds",
        "min_seconds", "max_seconds", "speedup"
    ])
    for count, avg, minimum, maximum in results:
        writer.writerow([
            count, avg, minimum, maximum, baseline / avg
        ])

print("===== FINAL SCALABILITY RESULTS =====")
print(f"{'Workers':<10}{'Avg Time (s)':<18}{'Speedup'}")

for count, avg, _, _ in results:
    print(f"{count:<10}{avg:<18.6f}{baseline / avg:.3f}x")

print("\nSHA-256 Verification: PASS")
print("Results saved to evidence/scalability/results.csv")
