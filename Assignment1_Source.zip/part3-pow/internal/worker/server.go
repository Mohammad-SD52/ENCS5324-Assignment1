package worker

import (
	"context"
	"errors"
	"log"

	"example.com/ads-assignment1/part3-pow/internal/pow"
	pb "example.com/ads-assignment1/part3-pow/proto"

	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

// Server implements the WorkerSearch gRPC service.
type Server struct {
	pb.UnimplementedWorkerSearchServer

	WorkerID string
}

// NewServer creates a worker service.
func NewServer(workerID string) *Server {
	return &Server{
		WorkerID: workerID,
	}
}

// Search receives a nonce range from the Coordinator
// and streams progress and the final result.
func (s *Server) Search(
	req *pb.SearchRequest,
	stream pb.WorkerSearch_SearchServer,
) error {

	// Validate the search request.
	if req.GetData() == "" {
		return status.Error(
			codes.InvalidArgument,
			"data must not be empty",
		)
	}

	if req.GetDifficulty() < 1 ||
		req.GetDifficulty() > 8 {
		return status.Error(
			codes.InvalidArgument,
			"difficulty must be between 1 and 8",
		)
	}

	if req.GetRangeStart() >= req.GetRangeEnd() {
		return status.Error(
			codes.InvalidArgument,
			"invalid nonce range",
		)
	}

	progressEvery := req.GetProgressInterval()

	if progressEvery == 0 {
		progressEvery = 50000
	}

	log.Printf(
		"Worker %s: starting job=%s range=[%d,%d)",
		s.WorkerID,
		req.GetJobId(),
		req.GetRangeStart(),
		req.GetRangeEnd(),
	)

	// Build a common update containing assignment details.
	newUpdate := func(
		state pb.SearchStatus,
		checked uint64,
	) *pb.SearchUpdate {
		return &pb.SearchUpdate{
			JobId:      req.GetJobId(),
			WorkerId:   s.WorkerID,
			Status:     state,
			Checked:    checked,
			RangeStart: req.GetRangeStart(),
			RangeEnd:   req.GetRangeEnd(),
		}
	}

	// Notify the Coordinator that the search started.
	if err := stream.Send(
		newUpdate(pb.SearchStatus_SEARCH_STARTED, 0),
	); err != nil {
		return err
	}

	// Run the actual proof-of-work algorithm.
	result, err := pow.SearchRange(
		stream.Context(),
		req.GetData(),
		int(req.GetDifficulty()),
		req.GetRangeStart(),
		req.GetRangeEnd(),
		progressEvery,

		// Send streaming progress updates.
		func(checked uint64) error {
			update := newUpdate(
				pb.SearchStatus_SEARCH_PROGRESS,
				checked,
			)

			if err := stream.Send(update); err != nil {
				return err
			}

			log.Printf(
				"Worker %s: job=%s checked=%d",
				s.WorkerID,
				req.GetJobId(),
				checked,
			)

			return nil
		},
	)

	if err != nil {
		if errors.Is(err, context.Canceled) ||
			errors.Is(err, context.DeadlineExceeded) {

			log.Printf(
				"Worker %s: search stopped job=%s checked=%d",
				s.WorkerID,
				req.GetJobId(),
				result.Checked,
			)

			return status.FromContextError(err).Err()
		}

		log.Printf(
			"Worker %s: search error: %v",
			s.WorkerID,
			err,
		)

		return err
	}

	// A valid nonce was found.
	if result.Found {
		update := newUpdate(
			pb.SearchStatus_SEARCH_FOUND,
			result.Checked,
		)

		update.Nonce = result.Nonce
		update.Hash = result.Hash

		log.Printf(
			"Worker %s: FOUND job=%s nonce=%d hash=%s",
			s.WorkerID,
			req.GetJobId(),
			result.Nonce,
			result.Hash,
		)

		return stream.Send(update)
	}

	// The entire range was searched without a solution.
	log.Printf(
		"Worker %s: EXHAUSTED job=%s range=[%d,%d) checked=%d",
		s.WorkerID,
		req.GetJobId(),
		req.GetRangeStart(),
		req.GetRangeEnd(),
		result.Checked,
	)

	return stream.Send(
		newUpdate(
			pb.SearchStatus_SEARCH_EXHAUSTED,
			result.Checked,
		),
	)
}
