package worker

import (
	"context"
	"io"
	"net"
	"testing"
	"time"

	"example.com/ads-assignment1/part3-pow/internal/pow"
	pb "example.com/ads-assignment1/part3-pow/proto"

	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/status"
)

// Start a real gRPC server on a temporary local port.
func newTestClient(t *testing.T) pb.WorkerSearchClient {
	t.Helper()

	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}

	server := grpc.NewServer()

	pb.RegisterWorkerSearchServer(
		server,
		NewServer("test-worker"),
	)

	go func() {
		_ = server.Serve(listener)
	}()

	conn, err := grpc.NewClient(
		listener.Addr().String(),
		grpc.WithTransportCredentials(
			insecure.NewCredentials(),
		),
	)
	if err != nil {
		server.Stop()
		t.Fatal(err)
	}

	t.Cleanup(func() {
		_ = conn.Close()
		server.Stop()
	})

	return pb.NewWorkerSearchClient(conn)
}

// Test 1: Search finds the expected nonce.
func TestWorkerFoundAndProgress(t *testing.T) {
	client := newTestClient(t)

	ctx, cancel := context.WithTimeout(
		context.Background(), 10*time.Second,
	)
	defer cancel()

	stream, err := client.Search(ctx, &pb.SearchRequest{
		JobId:            "test-found",
		Data:             "hello",
		Difficulty:       4,
		RangeStart:       0,
		RangeEnd:         100000,
		ProgressInterval: 10000,
	})
	if err != nil {
		t.Fatal(err)
	}

	var states []pb.SearchStatus
	var progressCount int
	var found *pb.SearchUpdate

	for {
		update, err := stream.Recv()
		if err == io.EOF {
			break
		}
		if err != nil {
			t.Fatal(err)
		}

		states = append(states, update.GetStatus())

		t.Logf(
			"gRPC update: %s checked=%d nonce=%d",
			update.GetStatus(),
			update.GetChecked(),
			update.GetNonce(),
		)

		if update.GetStatus() == pb.SearchStatus_SEARCH_PROGRESS {
			progressCount++
		}

		if update.GetStatus() == pb.SearchStatus_SEARCH_FOUND {
			found = update
		}
	}

	if len(states) == 0 ||
		states[0] != pb.SearchStatus_SEARCH_STARTED {
		t.Fatal("missing SEARCH_STARTED")
	}

	if progressCount == 0 {
		t.Fatal("no streaming progress received")
	}

	if found == nil {
		t.Fatal("missing SEARCH_FOUND")
	}

	if found.GetNonce() != 60067 ||
		found.GetChecked() != 60068 ||
		found.GetHash() != pow.HashNonce("hello", 60067) {
		t.Fatalf("incorrect result: %+v", found)
	}

	t.Log("FOUND and streaming progress verified")
}

// Test 2: Exhaust a range without finding a nonce.
func TestWorkerExhausted(t *testing.T) {
	client := newTestClient(t)

	ctx, cancel := context.WithTimeout(
		context.Background(), 10*time.Second,
	)
	defer cancel()

	stream, err := client.Search(ctx, &pb.SearchRequest{
		JobId:            "test-exhausted",
		Data:             "hello",
		Difficulty:       4,
		RangeStart:       0,
		RangeEnd:         1000,
		ProgressInterval: 250,
	})
	if err != nil {
		t.Fatal(err)
	}

	var last *pb.SearchUpdate

	for {
		update, err := stream.Recv()
		if err == io.EOF {
			break
		}
		if err != nil {
			t.Fatal(err)
		}

		last = update

		t.Logf(
			"gRPC update: %s checked=%d",
			update.GetStatus(),
			update.GetChecked(),
		)
	}

	if last == nil ||
		last.GetStatus() != pb.SearchStatus_SEARCH_EXHAUSTED ||
		last.GetChecked() != 1000 {
		t.Fatalf("unexpected final update: %+v", last)
	}

	t.Log("Range exhaustion verified")
}

// Test 3: Reject invalid input.
func TestWorkerInvalidRequest(t *testing.T) {
	client := newTestClient(t)

	ctx, cancel := context.WithTimeout(
		context.Background(), 10*time.Second,
	)
	defer cancel()

	stream, err := client.Search(ctx, &pb.SearchRequest{
		JobId:      "test-invalid",
		Data:       "",
		Difficulty: 4,
		RangeStart: 0,
		RangeEnd:   1000,
	})

	if err == nil {
		_, err = stream.Recv()
	}

	if status.Code(err) != codes.InvalidArgument {
		t.Fatalf(
			"expected InvalidArgument, got %v",
			err,
		)
	}

	t.Log("InvalidArgument correctly returned")
}

// Test 4: Cancel an active gRPC search.
func TestWorkerCancellation(t *testing.T) {
	client := newTestClient(t)

	ctx, cancel := context.WithTimeout(
		context.Background(), 15*time.Second,
	)
	defer cancel()

	stream, err := client.Search(ctx, &pb.SearchRequest{
		JobId:            "test-cancel",
		Data:             "hello",
		Difficulty:       8,
		RangeStart:       0,
		RangeEnd:         1000000000,
		ProgressInterval: 5000,
	})
	if err != nil {
		t.Fatal(err)
	}

	receivedProgress := false

	for {
		update, err := stream.Recv()
		if err != nil {
			t.Fatalf(
				"stream ended before cancellation: %v",
				err,
			)
		}

		if update.GetStatus() == pb.SearchStatus_SEARCH_PROGRESS {
			receivedProgress = true

			t.Logf(
				"Progress received: checked=%d",
				update.GetChecked(),
			)

			cancel()
			break
		}
	}

	if !receivedProgress {
		t.Fatal("no progress received")
	}

	_, err = stream.Recv()

	if status.Code(err) != codes.Canceled {
		t.Fatalf(
			"expected Canceled, got %v",
			err,
		)
	}

	t.Log("gRPC cancellation verified")
}
