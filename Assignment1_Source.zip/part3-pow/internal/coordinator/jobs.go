package coordinator

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"errors"
	"sort"
	"strings"
	"sync"
	"time"

	"example.com/ads-assignment1/part3-pow/internal/pow"
)

type JobStatus string

const (
	JobRunning   JobStatus = "RUNNING"
	JobFound     JobStatus = "FOUND"
	JobCancelled JobStatus = "CANCELLED"
)

var (
	ErrInvalidJob   = errors.New("invalid job input")
	ErrJobNotFound  = errors.New("job not found")
	ErrJobConflict  = errors.New("job already finished")
	ErrInvalidProof = errors.New("invalid proof of work")
)

// JobSnapshot is the public JSON representation.
type JobSnapshot struct {
	JobID          string    `json:"job_id"`
	Data           string    `json:"data"`
	Difficulty     int       `json:"difficulty"`
	Status         JobStatus `json:"status"`
	NoncesChecked  uint64    `json:"nonces_checked"`
	ElapsedSeconds float64   `json:"elapsed_seconds"`
	Nonce          *uint64   `json:"nonce,omitempty"`
	Hash           string    `json:"hash,omitempty"`
	StartedAt      time.Time `json:"started_at"`
}

type managedJob struct {
	info      JobSnapshot
	started   time.Time
	finished  time.Time
	ctx       context.Context
	cancel    context.CancelFunc
	listeners map[chan JobSnapshot]struct{}
}

type JobManager struct {
	mu   sync.Mutex
	jobs map[string]*managedJob
}

func NewJobManager() *JobManager {
	return &JobManager{
		jobs: make(map[string]*managedJob),
	}
}

// snapshotLocked calculates current elapsed time.
func (j *managedJob) snapshotLocked() JobSnapshot {
	s := j.info

	end := time.Now()
	if !j.finished.IsZero() {
		end = j.finished
	}

	s.ElapsedSeconds = end.Sub(j.started).Seconds()
	return s
}

// publishLocked sends updates to SSE subscribers.
// A slow subscriber keeps the newest event.
func (j *managedJob) publishLocked() {
	s := j.snapshotLocked()

	for ch := range j.listeners {
		select {
		case ch <- s:
		default:
			select {
			case <-ch:
			default:
			}
			select {
			case ch <- s:
			default:
			}
		}
	}
}

// Create starts a new independent job context.
func (m *JobManager) Create(
	data string,
	difficulty int,
) (JobSnapshot, error) {

	if strings.TrimSpace(data) == "" ||
		difficulty < 1 || difficulty > 8 {
		return JobSnapshot{}, ErrInvalidJob
	}

	randomBytes := make([]byte, 12)
	if _, err := rand.Read(randomBytes); err != nil {
		return JobSnapshot{}, err
	}

	id := "job-" + hex.EncodeToString(randomBytes)
	now := time.Now()
	ctx, cancel := context.WithCancel(context.Background())

	j := &managedJob{
		info: JobSnapshot{
			JobID:      id,
			Data:       data,
			Difficulty: difficulty,
			Status:     JobRunning,
			StartedAt:  now,
		},
		started:   now,
		ctx:       ctx,
		cancel:    cancel,
		listeners: make(map[chan JobSnapshot]struct{}),
	}

	m.mu.Lock()
	m.jobs[id] = j
	result := j.snapshotLocked()
	m.mu.Unlock()

	return result, nil
}

// Get retrieves a job safely.
func (m *JobManager) Get(id string) (JobSnapshot, error) {
	m.mu.Lock()
	defer m.mu.Unlock()

	j, ok := m.jobs[id]
	if !ok {
		return JobSnapshot{}, ErrJobNotFound
	}

	return j.snapshotLocked(), nil
}

// List retrieves all jobs.
func (m *JobManager) List() []JobSnapshot {
	m.mu.Lock()
	defer m.mu.Unlock()

	result := make([]JobSnapshot, 0, len(m.jobs))

	for _, j := range m.jobs {
		result = append(result, j.snapshotLocked())
	}

	sort.Slice(result, func(i, k int) bool {
		return result[i].StartedAt.Before(result[k].StartedAt)
	})

	return result
}

// Context is shared with the distributed search.
func (m *JobManager) Context(id string) (
	context.Context, error,
) {
	m.mu.Lock()
	defer m.mu.Unlock()

	j, ok := m.jobs[id]
	if !ok {
		return nil, ErrJobNotFound
	}

	return j.ctx, nil
}

// AddProgress records newly checked nonces.
// The scheduler will calculate unique progress deltas.
func (m *JobManager) AddProgress(
	id string,
	delta uint64,
) error {
	m.mu.Lock()
	defer m.mu.Unlock()

	j, ok := m.jobs[id]
	if !ok {
		return ErrJobNotFound
	}
	if j.info.Status != JobRunning {
		return ErrJobConflict
	}

	j.info.NoncesChecked += delta
	j.publishLocked()
	return nil
}

// MarkFound verifies and records a valid solution.
// Cancelling the context stops other searches.
func (m *JobManager) MarkFound(
	id string,
	nonce uint64,
	hash string,
) error {
	m.mu.Lock()
	defer m.mu.Unlock()

	j, ok := m.jobs[id]
	if !ok {
		return ErrJobNotFound
	}
	if j.info.Status != JobRunning {
		return ErrJobConflict
	}

	expected := pow.HashNonce(j.info.Data, nonce)
	if hash != expected ||
		!pow.ValidHash(hash, j.info.Difficulty) {
		return ErrInvalidProof
	}

	j.info.Status = JobFound
	j.info.Nonce = &nonce
	j.info.Hash = hash
	j.finished = time.Now()

	j.cancel()
	j.publishLocked()
	return nil
}

// Cancel stops the job and its associated context.
func (m *JobManager) Cancel(id string) (
	JobSnapshot, error,
) {
	m.mu.Lock()
	defer m.mu.Unlock()

	j, ok := m.jobs[id]
	if !ok {
		return JobSnapshot{}, ErrJobNotFound
	}
	if j.info.Status != JobRunning {
		return JobSnapshot{}, ErrJobConflict
	}

	j.info.Status = JobCancelled
	j.finished = time.Now()

	j.cancel()
	j.publishLocked()
	return j.snapshotLocked(), nil
}

// Subscribe registers a live progress listener.
// The caller must invoke unsubscribe when finished.
func (m *JobManager) Subscribe(id string) (
	<-chan JobSnapshot,
	func(),
	error,
) {
	m.mu.Lock()

	j, ok := m.jobs[id]
	if !ok {
		m.mu.Unlock()
		return nil, nil, ErrJobNotFound
	}

	ch := make(chan JobSnapshot, 16)
	j.listeners[ch] = struct{}{}
	ch <- j.snapshotLocked()
	m.mu.Unlock()

	unsubscribe := func() {
		m.mu.Lock()
		delete(j.listeners, ch)
		m.mu.Unlock()
	}

	return ch, unsubscribe, nil
}
