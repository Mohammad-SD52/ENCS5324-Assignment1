package coordinator

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"time"
)

// HTTPAPI connects the REST endpoints to the
// Job Manager and Worker Registry.
type HTTPAPI struct {
	Jobs       *JobManager
	Registry   *Registry
	OnJobStart func(string)
}

// NewHTTPHandler creates the REST API routes.
//
// OnJobStart will later connect the API to
// the distributed job scheduler.
func NewHTTPHandler(
	jobs *JobManager,
	registry *Registry,
	onJobStart func(string),
) http.Handler {

	api := &HTTPAPI{
		Jobs:       jobs,
		Registry:   registry,
		OnJobStart: onJobStart,
	}

	mux := http.NewServeMux()

	mux.HandleFunc("GET /{$}", dashboardHandler)

	mux.HandleFunc("POST /jobs", api.createJob)
	mux.HandleFunc("GET /jobs", api.listJobs)
	mux.HandleFunc("GET /jobs/{id}", api.getJob)
	mux.HandleFunc("DELETE /jobs/{id}", api.cancelJob)
	mux.HandleFunc(
		"GET /jobs/{id}/events",
		api.streamJobEvents,
	)
	mux.HandleFunc("GET /workers", api.listWorkers)

	return mux
}

// Write a JSON response.
func writeJSON(
	w http.ResponseWriter,
	code int,
	value any,
) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(value)
}

// Write errors in JSON format.
func writeAPIError(
	w http.ResponseWriter,
	code int,
	message string,
) {
	writeJSON(w, code, map[string]string{
		"error": message,
	})
}

// POST /jobs
func (api *HTTPAPI) createJob(
	w http.ResponseWriter,
	r *http.Request,
) {
	var request struct {
		Data       string `json:"data"`
		Difficulty int    `json:"difficulty"`
	}

	// Limit request body size to 1 MiB.
	r.Body = http.MaxBytesReader(
		w, r.Body, 1<<20,
	)

	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()

	if err := decoder.Decode(&request); err != nil {
		writeAPIError(
			w, http.StatusBadRequest,
			"invalid JSON request",
		)
		return
	}

	// Reject additional JSON values.
	var extra any
	if err := decoder.Decode(&extra); err != io.EOF {
		writeAPIError(
			w, http.StatusBadRequest,
			"request must contain one JSON object",
		)
		return
	}

	job, err := api.Jobs.Create(
		request.Data,
		request.Difficulty,
	)

	if err != nil {
		if errors.Is(err, ErrInvalidJob) {
			writeAPIError(
				w, http.StatusBadRequest,
				"data is required and difficulty must be 1-8",
			)
			return
		}

		writeAPIError(
			w, http.StatusInternalServerError,
			"could not create job",
		)
		return
	}

	// The job was accepted for processing.
	writeJSON(
		w,
		http.StatusAccepted,
		map[string]string{
			"job_id": job.JobID,
		},
	)

	// The scheduler will be attached later.
	if api.OnJobStart != nil {
		go api.OnJobStart(job.JobID)
	}
}

// GET /jobs
func (api *HTTPAPI) listJobs(
	w http.ResponseWriter,
	r *http.Request,
) {
	writeJSON(
		w,
		http.StatusOK,
		api.Jobs.List(),
	)
}

// GET /jobs/{id}
func (api *HTTPAPI) getJob(
	w http.ResponseWriter,
	r *http.Request,
) {
	id := r.PathValue("id")

	job, err := api.Jobs.Get(id)
	if err != nil {
		writeAPIError(
			w, http.StatusNotFound,
			"job not found",
		)
		return
	}

	writeJSON(w, http.StatusOK, job)
}

// DELETE /jobs/{id}
func (api *HTTPAPI) cancelJob(
	w http.ResponseWriter,
	r *http.Request,
) {
	id := r.PathValue("id")

	job, err := api.Jobs.Cancel(id)

	switch {
	case errors.Is(err, ErrJobNotFound):
		writeAPIError(
			w, http.StatusNotFound,
			"job not found",
		)
		return

	case errors.Is(err, ErrJobConflict):
		writeAPIError(
			w, http.StatusConflict,
			"job already finished",
		)
		return

	case err != nil:
		writeAPIError(
			w, http.StatusInternalServerError,
			"could not cancel job",
		)
		return
	}

	writeJSON(w, http.StatusOK, job)
}

// GET /workers
func (api *HTTPAPI) listWorkers(
	w http.ResponseWriter,
	r *http.Request,
) {
	writeJSON(
		w,
		http.StatusOK,
		api.Registry.ListWorkers(),
	)
}

// GET /jobs/{id}/events
//
// Server-Sent Events provide live progress updates.
func (api *HTTPAPI) streamJobEvents(
	w http.ResponseWriter,
	r *http.Request,
) {
	id := r.PathValue("id")

	updates, unsubscribe, err := api.Jobs.Subscribe(id)
	if err != nil {
		writeAPIError(
			w, http.StatusNotFound,
			"job not found",
		)
		return
	}
	defer unsubscribe()

	flusher, ok := w.(http.Flusher)
	if !ok {
		writeAPIError(
			w, http.StatusInternalServerError,
			"streaming is not supported",
		)
		return
	}

	w.Header().Set(
		"Content-Type",
		"text/event-stream",
	)
	w.Header().Set(
		"Cache-Control",
		"no-cache",
	)
	w.Header().Set(
		"X-Accel-Buffering",
		"no",
	)

	w.WriteHeader(http.StatusOK)
	flusher.Flush()

	// Keep the connection alive during quiet periods.
	ticker := time.NewTicker(10 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-r.Context().Done():
			return

		case snapshot := <-updates:
			payload, err := json.Marshal(snapshot)
			if err != nil {
				return
			}

			eventType := "progress"

			// Terminal states use a final SSE event.
			if snapshot.Status != JobRunning {
				eventType = "final"
			}

			_, err = fmt.Fprintf(
				w,
				"event: %s\ndata: %s\n\n",
				eventType,
				payload,
			)
			if err != nil {
				return
			}

			flusher.Flush()

			// Close the stream after the final event.
			if eventType == "final" {
				return
			}

		case <-ticker.C:
			if _, err := fmt.Fprint(
				w, ": keepalive\n\n",
			); err != nil {
				return
			}

			flusher.Flush()
		}
	}
}
