package coordinator

import (
	"context"
	"log"
	"net"
	"sort"
	"strings"
	"sync"
	"time"

	pb "example.com/ads-assignment1/part3-pow/proto"

	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

// WorkerInfo describes a registered worker.
type WorkerInfo struct {
	WorkerID      string    `json:"worker_id"`
	GRPCAddress   string    `json:"grpc_address"`
	CurrentJobID  string    `json:"current_job_id"`
	LastHeartbeat time.Time `json:"last_heartbeat"`
	Alive         bool      `json:"alive"`
}

// Registry manages workers and their heartbeats.
type Registry struct {
	pb.UnimplementedCoordinatorRegistryServer

	mu      sync.RWMutex
	workers map[string]*WorkerInfo
	timeout time.Duration
}

// NewRegistry creates the worker registry.
func NewRegistry(timeout time.Duration) *Registry {
	return &Registry{
		workers: make(map[string]*WorkerInfo),
		timeout: timeout,
	}
}

// RegisterWorker is called when a worker starts.
func (r *Registry) RegisterWorker(
	ctx context.Context,
	req *pb.RegisterWorkerRequest,
) (*pb.RegisterWorkerResponse, error) {

	id := strings.TrimSpace(req.GetWorkerId())
	addr := strings.TrimSpace(req.GetGrpcAddress())

	if id == "" || addr == "" {
		return nil, status.Error(
			codes.InvalidArgument,
			"worker ID and gRPC address are required",
		)
	}

	if _, _, err := net.SplitHostPort(addr); err != nil {
		return nil, status.Error(
			codes.InvalidArgument,
			"invalid worker gRPC address",
		)
	}

	now := time.Now()

	r.mu.Lock()
	defer r.mu.Unlock()

	if existing, ok := r.workers[id]; ok {
		if existing.GRPCAddress != addr &&
			existing.Alive &&
			now.Sub(existing.LastHeartbeat) <= r.timeout {

			return &pb.RegisterWorkerResponse{
				Accepted: false,
				Message:  "worker ID is already in use",
			}, nil
		}

		existing.GRPCAddress = addr
		existing.LastHeartbeat = now
		existing.Alive = true

		log.Printf(
			"Worker re-registered: id=%s address=%s",
			id, addr,
		)
	} else {
		r.workers[id] = &WorkerInfo{
			WorkerID:      id,
			GRPCAddress:   addr,
			LastHeartbeat: now,
			Alive:         true,
		}

		log.Printf(
			"Worker registered: id=%s address=%s",
			id, addr,
		)
	}

	return &pb.RegisterWorkerResponse{
		Accepted: true,
		Message:  "registration successful",
	}, nil
}

// Heartbeat updates the worker's last-seen time.
func (r *Registry) Heartbeat(
	ctx context.Context,
	req *pb.HeartbeatRequest,
) (*pb.HeartbeatResponse, error) {

	id := strings.TrimSpace(req.GetWorkerId())

	r.mu.Lock()
	defer r.mu.Unlock()

	w, exists := r.workers[id]
	if !exists || !w.Alive {
		return &pb.HeartbeatResponse{
			Accepted: false,
		}, nil
	}

	w.LastHeartbeat = time.Now()
	w.CurrentJobID = req.GetCurrentJobId()

	log.Printf(
		"Heartbeat OK: worker=%s job=%q",
		id,
		w.CurrentJobID,
	)

	return &pb.HeartbeatResponse{
		Accepted: true,
	}, nil
}

// MarkDeadWorkers detects expired heartbeats.
func (r *Registry) MarkDeadWorkers() {
	r.mu.Lock()
	defer r.mu.Unlock()

	now := time.Now()

	for _, w := range r.workers {
		if w.Alive &&
			now.Sub(w.LastHeartbeat) > r.timeout {

			w.Alive = false

			log.Printf(
				"WORKER OFFLINE: id=%s last_seen=%s",
				w.WorkerID,
				w.LastHeartbeat.Format(time.RFC3339),
			)
		}
	}
}

// ListWorkers returns a safe copy of worker states.
// This will later support GET /workers.
func (r *Registry) ListWorkers() []WorkerInfo {
	r.mu.RLock()
	defer r.mu.RUnlock()

	result := make([]WorkerInfo, 0, len(r.workers))

	for _, w := range r.workers {
		copy := *w
		result = append(result, copy)
	}

	sort.Slice(result, func(i, j int) bool {
		return result[i].WorkerID < result[j].WorkerID
	})

	return result
}
