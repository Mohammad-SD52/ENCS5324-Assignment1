package coordinator

import (
	"context"
	"errors"
	"sync"
	"testing"

	"example.com/ads-assignment1/part3-pow/internal/pow"
)

func TestCreateAndFindJob(t *testing.T) {
	m := NewJobManager()

	job, err := m.Create("hello", 4)
	if err != nil {
		t.Fatal(err)
	}

	if job.JobID == "" || job.Status != JobRunning {
		t.Fatalf("invalid new job: %+v", job)
	}

	if err := m.AddProgress(job.JobID, 60068); err != nil {
		t.Fatal(err)
	}

	hash := pow.HashNonce("hello", 60067)

	if err := m.MarkFound(
		job.JobID, 60067, hash,
	); err != nil {
		t.Fatal(err)
	}

	found, err := m.Get(job.JobID)
	if err != nil {
		t.Fatal(err)
	}

	if found.Status != JobFound ||
		found.Nonce == nil ||
		*found.Nonce != 60067 ||
		found.NoncesChecked != 60068 {
		t.Fatalf("invalid result: %+v", found)
	}

	ctx, _ := m.Context(job.JobID)

	if !errors.Is(ctx.Err(), context.Canceled) {
		t.Fatal("job context was not cancelled")
	}

	t.Logf("FOUND job=%s nonce=%d",
		found.JobID, *found.Nonce)
}

func TestJobCancellationAndConflict(t *testing.T) {
	m := NewJobManager()

	job, err := m.Create("cancel-test", 8)
	if err != nil {
		t.Fatal(err)
	}

	cancelled, err := m.Cancel(job.JobID)
	if err != nil {
		t.Fatal(err)
	}

	if cancelled.Status != JobCancelled {
		t.Fatal("job was not cancelled")
	}

	_, err = m.Cancel(job.JobID)

	if !errors.Is(err, ErrJobConflict) {
		t.Fatalf("expected conflict, got %v", err)
	}

	t.Log("Cancellation and 409 conflict condition verified")
}

func TestInvalidAndUnknownJob(t *testing.T) {
	m := NewJobManager()

	_, err := m.Create("", 4)
	if !errors.Is(err, ErrInvalidJob) {
		t.Fatal("expected invalid input error")
	}

	_, err = m.Create("hello", 9)
	if !errors.Is(err, ErrInvalidJob) {
		t.Fatal("expected invalid difficulty error")
	}

	_, err = m.Get("unknown-job")
	if !errors.Is(err, ErrJobNotFound) {
		t.Fatal("expected unknown job error")
	}
}

func TestConcurrentJobs(t *testing.T) {
	m := NewJobManager()
	var wg sync.WaitGroup
	var ids []string

	for i := 0; i < 3; i++ {
		job, err := m.Create("parallel", 5)
		if err != nil {
			t.Fatal(err)
		}

		ids = append(ids, job.JobID)
	}

	for _, id := range ids {
		wg.Add(1)

		go func(jobID string) {
			defer wg.Done()

			for i := 0; i < 100; i++ {
				if err := m.AddProgress(jobID, 1); err != nil {
					t.Error(err)
					return
				}
			}
		}(id)
	}

	wg.Wait()

	if len(m.List()) != 3 {
		t.Fatal("expected 3 jobs")
	}

	for _, id := range ids {
		job, _ := m.Get(id)
		if job.NoncesChecked != 100 {
			t.Fatalf("unexpected progress: %+v", job)
		}
	}

	t.Log("Three concurrent jobs verified")
}

func TestJobSubscription(t *testing.T) {
	m := NewJobManager()

	job, err := m.Create("hello", 4)
	if err != nil {
		t.Fatal(err)
	}

	events, unsubscribe, err := m.Subscribe(job.JobID)
	if err != nil {
		t.Fatal(err)
	}
	defer unsubscribe()

	initial := <-events
	if initial.Status != JobRunning {
		t.Fatal("expected initial RUNNING event")
	}

	if err := m.AddProgress(job.JobID, 100); err != nil {
		t.Fatal(err)
	}

	update := <-events
	if update.NoncesChecked != 100 {
		t.Fatal("progress event was not received")
	}

	_, err = m.Cancel(job.JobID)
	if err != nil {
		t.Fatal(err)
	}

	final := <-events
	if final.Status != JobCancelled {
		t.Fatal("final cancellation event missing")
	}

	t.Log("Initial, progress and final events verified")
}
