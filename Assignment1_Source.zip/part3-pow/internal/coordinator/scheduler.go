package coordinator

import (
	"context"
	"errors"
	"fmt"
	"io"
	"log"
	"math"
	"sync"
	"time"

	pb "example.com/ads-assignment1/part3-pow/proto"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

type SchedulerConfig struct {
	RangeSize        uint64
	ProgressInterval uint64
	MaxWorkers       int
	RangeTimeout     time.Duration
}

type nonceRange struct {
	start uint64
	end   uint64
}

type rangeOutcome struct {
	work nonceRange
	err  error
}

// Scheduler distributes jobs among available workers.
type Scheduler struct {
	jobs     *JobManager
	registry *Registry
	config   SchedulerConfig

	mu         sync.Mutex
	busy       map[string]bool
	cooldown   map[string]time.Time
	activeJobs map[string]struct{}
}

func NewScheduler(
	jobs *JobManager,
	registry *Registry,
	config SchedulerConfig,
) (*Scheduler, error) {

	if config.RangeSize == 0 ||
		config.ProgressInterval == 0 ||
		config.MaxWorkers < 1 ||
		config.RangeTimeout <= 0 {

		return nil, errors.New(
			"invalid scheduler configuration",
		)
	}

	return &Scheduler{
		jobs:       jobs,
		registry:   registry,
		config:     config,
		busy:       make(map[string]bool),
		cooldown:   make(map[string]time.Time),
		activeJobs: make(map[string]struct{}),
	}, nil
}

// Start schedules a job asynchronously.
func (s *Scheduler) Start(jobID string) {
	s.mu.Lock()

	if _, exists := s.activeJobs[jobID]; exists {
		s.mu.Unlock()
		return
	}

	s.activeJobs[jobID] = struct{}{}
	s.mu.Unlock()

	go s.run(jobID)
}

// shareLimit lets concurrent jobs share workers.
func (s *Scheduler) shareLimit() int {
	workers := s.registry.ListWorkers()

	alive := 0
	for _, w := range workers {
		if w.Alive &&
			time.Since(w.LastHeartbeat) <= s.registry.timeout {
			alive++
		}
	}

	if alive > s.config.MaxWorkers {
		alive = s.config.MaxWorkers
	}

	if alive == 0 {
		return 0
	}

	s.mu.Lock()
	active := len(s.activeJobs)
	s.mu.Unlock()

	if active < 1 {
		active = 1
	}

	limit := (alive + active - 1) / active

	if limit < 1 {
		limit = 1
	}

	return limit
}

// claimWorker reserves a healthy, idle worker.
func (s *Scheduler) claimWorker() (
	WorkerInfo, bool,
) {
	workers := s.registry.ListWorkers()

	s.mu.Lock()
	defer s.mu.Unlock()

	if len(s.busy) >= s.config.MaxWorkers {
		return WorkerInfo{}, false
	}

	now := time.Now()

	for _, w := range workers {
		if !w.Alive ||
			now.Sub(w.LastHeartbeat) > s.registry.timeout {
			continue
		}

		if s.busy[w.WorkerID] {
			continue
		}

		if now.Before(s.cooldown[w.WorkerID]) {
			continue
		}

		s.busy[w.WorkerID] = true
		return w, true
	}

	return WorkerInfo{}, false
}

func (s *Scheduler) releaseWorker(
	id string,
	failed bool,
) {
	s.mu.Lock()
	defer s.mu.Unlock()

	delete(s.busy, id)

	if failed {
		s.cooldown[id] = time.Now().Add(
			2 * time.Second,
		)
	} else {
		delete(s.cooldown, id)
	}
}

// run continuously allocates ranges until the
// job is found or cancelled.
func (s *Scheduler) run(jobID string) {
	defer func() {
		s.mu.Lock()
		delete(s.activeJobs, jobID)
		s.mu.Unlock()
	}()

	job, err := s.jobs.Get(jobID)
	if err != nil || job.Status != JobRunning {
		return
	}

	ctx, err := s.jobs.Context(jobID)
	if err != nil {
		return
	}

	log.Printf(
		"SCHEDULER: job=%s started difficulty=%d",
		jobID, job.Difficulty,
	)

	var next uint64
	var pending []nonceRange
	var inFlight int
	spaceExhausted := false

	results := make(
		chan rangeOutcome,
		s.config.MaxWorkers*2,
	)

	ticker := time.NewTicker(150 * time.Millisecond)
	defer ticker.Stop()

	for {
		if ctx.Err() != nil {
			log.Printf(
				"SCHEDULER: job=%s stopped",
				jobID,
			)
			return
		}

		limit := s.shareLimit()

		// Fill the available worker slots.
		for inFlight < limit {
			w, ok := s.claimWorker()
			if !ok {
				break
			}

			var work nonceRange

			if len(pending) > 0 {
				last := len(pending) - 1
				work = pending[last]
				pending = pending[:last]

			} else {
				if spaceExhausted {
					s.releaseWorker(w.WorkerID, false)
					break
				}

				start := next
				end := next + s.config.RangeSize

				// Avoid uint64 overflow.
				if end < start {
					end = math.MaxUint64
				}

				if start >= end {
					spaceExhausted = true
					s.releaseWorker(w.WorkerID, false)
					break
				}

				work = nonceRange{
					start: start,
					end:   end,
				}

				next = end

				if next == math.MaxUint64 {
					spaceExhausted = true
				}
			}

			inFlight++

			log.Printf(
				"ASSIGNED: job=%s worker=%s range=[%d,%d)",
				jobID,
				w.WorkerID,
				work.start,
				work.end,
			)

			go func(
				worker WorkerInfo,
				r nonceRange,
			) {
				err := s.searchOnWorker(
					ctx, job, worker, r,
				)

				s.releaseWorker(
					worker.WorkerID,
					err != nil,
				)

				select {
				case results <- rangeOutcome{
					work: r,
					err:  err,
				}:
				case <-ctx.Done():
				}
			}(w, work)
		}

		if spaceExhausted &&
			inFlight == 0 &&
			len(pending) == 0 {
			log.Printf(
				"SCHEDULER: job=%s exhausted uint64 search space",
				jobID,
			)
			return
		}

		select {
		case result := <-results:
			inFlight--

			if result.err != nil &&
				ctx.Err() == nil {

				// Retry the entire failed range.
				pending = append(
					pending, result.work,
				)

				log.Printf(
					"REASSIGN QUEUED: job=%s range=[%d,%d) error=%v",
					jobID,
					result.work.start,
					result.work.end,
					result.err,
				)
			}

		case <-ticker.C:
			// Retry scheduling when workers become free.

		case <-ctx.Done():
			return
		}
	}
}

// monitorWorker cancels an active Search call
// when the assigned worker loses its heartbeat.
func (s *Scheduler) monitorWorker(
	ctx context.Context,
	cancel context.CancelFunc,
	workerID string,
) {
	ticker := time.NewTicker(time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return

		case <-ticker.C:
			healthy := false

			for _, w := range s.registry.ListWorkers() {
				if w.WorkerID == workerID &&
					w.Alive &&
					time.Since(w.LastHeartbeat) <= s.registry.timeout {
					healthy = true
					break
				}
			}

			if !healthy {
				log.Printf(
					"WORKER LOST DURING SEARCH: id=%s",
					workerID,
				)

				cancel()
				return
			}
		}
	}
}

// searchOnWorker runs a real gRPC streaming search.
func (s *Scheduler) searchOnWorker(
	jobCtx context.Context,
	job JobSnapshot,
	worker WorkerInfo,
	work nonceRange,
) error {

	ctx, cancel := context.WithTimeout(
		jobCtx,
		s.config.RangeTimeout,
	)
	defer cancel()

	go s.monitorWorker(
		ctx, cancel, worker.WorkerID,
	)

	conn, err := grpc.NewClient(
		worker.GRPCAddress,
		grpc.WithTransportCredentials(
			insecure.NewCredentials(),
		),
	)
	if err != nil {
		return err
	}
	defer conn.Close()

	client := pb.NewWorkerSearchClient(conn)

	stream, err := client.Search(
		ctx,
		&pb.SearchRequest{
			JobId:            job.JobID,
			Data:             job.Data,
			Difficulty:       int32(job.Difficulty),
			RangeStart:       work.start,
			RangeEnd:         work.end,
			ProgressInterval: s.config.ProgressInterval,
		},
	)
	if err != nil {
		return err
	}

	var lastChecked uint64
	rangeLength := work.end - work.start

	for {
		update, err := stream.Recv()

		if errors.Is(err, io.EOF) {
			return errors.New(
				"stream ended without a final search result",
			)
		}
		if err != nil {
			return err
		}

		// Validate the identity and range.
		if update.GetJobId() != job.JobID ||
			update.GetWorkerId() != worker.WorkerID ||
			update.GetRangeStart() != work.start ||
			update.GetRangeEnd() != work.end {
			return errors.New(
				"worker sent inconsistent search update",
			)
		}

		checked := update.GetChecked()

		if checked < lastChecked ||
			checked > rangeLength {
			return errors.New(
				"invalid progress count",
			)
		}

		// Count newly reported attempts.
		if checked > lastChecked {
			delta := checked - lastChecked

			if err := s.jobs.AddProgress(
				job.JobID, delta,
			); err != nil {
				return err
			}

			lastChecked = checked
		}

		switch update.GetStatus() {

		case pb.SearchStatus_SEARCH_STARTED:
			// Worker acknowledged the assignment.

		case pb.SearchStatus_SEARCH_PROGRESS:
			// Progress has already been recorded.

		case pb.SearchStatus_SEARCH_FOUND:
			nonce := update.GetNonce()

			if nonce < work.start ||
				nonce >= work.end {
				return errors.New(
					"found nonce is outside assigned range",
				)
			}

			if err := s.jobs.MarkFound(
				job.JobID,
				nonce,
				update.GetHash(),
			); err != nil {
				return err
			}

			log.Printf(
				"FOUND: job=%s worker=%s nonce=%d hash=%s",
				job.JobID,
				worker.WorkerID,
				nonce,
				update.GetHash(),
			)

			return nil

		case pb.SearchStatus_SEARCH_EXHAUSTED:
			if checked != rangeLength {
				return fmt.Errorf(
					"incomplete range: checked=%d expected=%d",
					checked,
					rangeLength,
				)
			}

			log.Printf(
				"RANGE COMPLETED: job=%s worker=%s range=[%d,%d)",
				job.JobID,
				worker.WorkerID,
				work.start,
				work.end,
			)

			return nil

		default:
			return errors.New(
				"unknown worker search status",
			)
		}
	}
}
