package pow

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"strconv"
	"strings"
)

// Result stores the result of a nonce search.
type Result struct {
	Nonce   uint64
	Hash    string
	Checked uint64
	Found   bool
}

// HashNonce calculates SHA-256(data + decimal nonce).
func HashNonce(data string, nonce uint64) string {
	input := data + strconv.FormatUint(nonce, 10)
	digest := sha256.Sum256([]byte(input))
	return hex.EncodeToString(digest[:])
}

// ValidHash checks the required leading hexadecimal zeros.
func ValidHash(hash string, difficulty int) bool {
	if difficulty < 1 || difficulty > 8 {
		return false
	}

	return strings.HasPrefix(
		hash,
		strings.Repeat("0", difficulty),
	)
}

// SearchRange searches the interval [start, end).
// It supports context cancellation and progress updates.
func SearchRange(
	ctx context.Context,
	data string,
	difficulty int,
	start uint64,
	end uint64,
	progressEvery uint64,
	onProgress func(uint64) error,
) (Result, error) {

	var result Result

	if difficulty < 1 || difficulty > 8 {
		return result, errors.New(
			"difficulty must be between 1 and 8",
		)
	}

	if start >= end {
		return result, errors.New(
			"range start must be less than range end",
		)
	}

	for nonce := start; nonce < end; nonce++ {

		// Check cancellation before each attempt.
		if err := ctx.Err(); err != nil {
			return result, err
		}

		hash := HashNonce(data, nonce)
		result.Checked++

		if ValidHash(hash, difficulty) {
			result.Nonce = nonce
			result.Hash = hash
			result.Found = true
			return result, nil
		}

		// Send progress updates at configured intervals.
		if onProgress != nil &&
			progressEvery > 0 &&
			result.Checked%progressEvery == 0 {

			if err := onProgress(result.Checked); err != nil {
				return result, err
			}
		}
	}

	// The range was exhausted without a valid nonce.
	return result, nil
}
