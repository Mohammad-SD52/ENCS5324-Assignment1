package pow

import (
	"context"
	"errors"
	"testing"
)

// Test finding a known valid nonce.
func TestFindValidNonce(t *testing.T) {
	result, err := SearchRange(
		context.Background(),
		"hello", 4, 0, 100000, 1000, nil,
	)

	if err != nil {
		t.Fatal(err)
	}

	expectedHash := "0000e49eab06aa7a6b3aef7708991b91a7e01451fd67f520b832b89b18f4e7de"

	if !result.Found ||
		result.Nonce != 60067 ||
		result.Hash != expectedHash ||
		result.Checked != 60068 {
		t.Fatalf("unexpected result: %+v", result)
	}

	t.Logf("FOUND nonce=%d hash=%s checked=%d",
		result.Nonce, result.Hash, result.Checked)
}

// Test a range that contains no valid nonce.
func TestExhaustedRange(t *testing.T) {
	result, err := SearchRange(
		context.Background(),
		"hello", 4, 0, 1000, 100, nil,
	)

	if err != nil {
		t.Fatal(err)
	}

	if result.Found || result.Checked != 1000 {
		t.Fatalf("expected exhausted range: %+v", result)
	}
}

// Test context cancellation.
func TestCancellation(t *testing.T) {
	ctx, cancel := context.WithCancel(
		context.Background(),
	)
	cancel()

	_, err := SearchRange(
		ctx, "hello", 6, 0, 1000000, 1000, nil,
	)

	if !errors.Is(err, context.Canceled) {
		t.Fatalf("expected cancellation, got %v", err)
	}
}

// Test invalid difficulty.
func TestInvalidDifficulty(t *testing.T) {
	_, err := SearchRange(
		context.Background(),
		"hello", 9, 0, 1000, 100, nil,
	)

	if err == nil {
		t.Fatal("expected invalid difficulty error")
	}
}

// Test that progress updates are delivered.
func TestProgressUpdates(t *testing.T) {
	var updates []uint64

	result, err := SearchRange(
		context.Background(),
		"hello", 8, 0, 10, 3,
		func(checked uint64) error {
			updates = append(updates, checked)
			return nil
		},
	)

	if err != nil {
		t.Fatal(err)
	}

	if result.Found || result.Checked != 10 {
		t.Fatalf("unexpected search result: %+v", result)
	}

	expected := []uint64{3, 6, 9}

	if len(updates) != len(expected) {
		t.Fatalf("unexpected updates: %v", updates)
	}

	for i := range expected {
		if updates[i] != expected[i] {
			t.Fatalf("unexpected updates: %v", updates)
		}
	}
}
