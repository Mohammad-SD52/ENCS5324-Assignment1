package main

import (
	"context"
	"errors"
	"flag"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"example.com/ads-assignment1/part3-pow/internal/coordinator"
	pb "example.com/ads-assignment1/part3-pow/proto"

	"google.golang.org/grpc"
)

func main() {
	// Coordinator network configuration.
	grpcAddr := flag.String(
		"grpc",
		"127.0.0.1:50052",
		"Coordinator gRPC listening address",
	)

	httpAddr := flag.String(
		"http",
		"127.0.0.1:8080",
		"Coordinator HTTP listening address",
	)

	// Worker monitoring configuration.
	heartbeatTimeout := flag.Duration(
		"heartbeat-timeout",
		8*time.Second,
		"Worker heartbeat timeout",
	)

	// Distributed search configuration.
	maxWorkers := flag.Int(
		"workers",
		8,
		"Maximum workers used by the scheduler",
	)

	rangeSize := flag.Uint64(
		"range-size",
		1000000,
		"Number of nonces per search range",
	)

	progressInterval := flag.Uint64(
		"progress-interval",
		50000,
		"Nonce attempts between progress updates",
	)

	rangeTimeout := flag.Duration(
		"range-timeout",
		60*time.Second,
		"Maximum time allowed for one range",
	)

	flag.Parse()

	if *heartbeatTimeout <= 0 {
		log.Fatal("heartbeat timeout must be positive")
	}

	// Handle Ctrl+C and termination signals.
	ctx, stop := signal.NotifyContext(
		context.Background(),
		os.Interrupt,
		syscall.SIGTERM,
	)
	defer stop()

	// Shared application components.
	registry := coordinator.NewRegistry(
		*heartbeatTimeout,
	)

	jobs := coordinator.NewJobManager()

	// Create the distributed job scheduler.
	scheduler, err := coordinator.NewScheduler(
		jobs,
		registry,
		coordinator.SchedulerConfig{
			RangeSize:        *rangeSize,
			ProgressInterval: *progressInterval,
			MaxWorkers:       *maxWorkers,
			RangeTimeout:     *rangeTimeout,
		},
	)
	if err != nil {
		log.Fatalf("Scheduler configuration: %v", err)
	}

	// gRPC server: worker registration and heartbeat.
	grpcListener, err := net.Listen("tcp", *grpcAddr)
	if err != nil {
		log.Fatalf("Cannot start gRPC listener: %v", err)
	}
	defer grpcListener.Close()

	grpcServer := grpc.NewServer()

	pb.RegisterCoordinatorRegistryServer(
		grpcServer,
		registry,
	)

	// REST API: connected to the scheduler.
	httpHandler := coordinator.NewHTTPHandler(
		jobs,
		registry,
		scheduler.Start,
	)

	httpListener, err := net.Listen("tcp", *httpAddr)
	if err != nil {
		log.Fatalf("Cannot start HTTP listener: %v", err)
	}
	defer httpListener.Close()

	httpServer := &http.Server{
		Handler:           httpHandler,
		ReadHeaderTimeout: 5 * time.Second,
	}

	// Start gRPC server.
	go func() {
		if err := grpcServer.Serve(grpcListener); err != nil {
			log.Printf("gRPC server error: %v", err)
			stop()
		}
	}()

	// Start REST server.
	go func() {
		err := httpServer.Serve(httpListener)

		if err != nil &&
			!errors.Is(err, http.ErrServerClosed) {

			log.Printf("HTTP server error: %v", err)
			stop()
		}
	}()

	log.Println("================================")
	log.Println("ADS Distributed Proof-of-Work")
	log.Printf("HTTP server: %s", *httpAddr)
	log.Printf("gRPC server: %s", *grpcAddr)
	log.Printf("Maximum workers: %d", *maxWorkers)
	log.Printf("Range size: %d", *rangeSize)
	log.Printf("Progress interval: %d", *progressInterval)
	log.Printf("Range timeout: %s", *rangeTimeout)
	log.Printf("Heartbeat timeout: %s", *heartbeatTimeout)
	log.Println("Distributed scheduler enabled")
	log.Println("================================")

	// Periodically detect worker failures.
	ticker := time.NewTicker(2 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			registry.MarkDeadWorkers()

		case <-ctx.Done():
			log.Println("Coordinator shutting down")

			shutdownCtx, cancel := context.WithTimeout(
				context.Background(),
				5*time.Second,
			)
			defer cancel()

			if err := httpServer.Shutdown(shutdownCtx); err != nil {
				log.Printf("HTTP shutdown error: %v", err)
			}

			grpcServer.GracefulStop()

			log.Println("Coordinator stopped")
			return
		}
	}
}
