package main

import (
	"context"
	"flag"
	"log"
	"net"
	"os"
	"os/signal"
	"sync"
	"syscall"
	"time"

	"example.com/ads-assignment1/part3-pow/internal/worker"
	pb "example.com/ads-assignment1/part3-pow/proto"

	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/status"
)

// ManagedWorker tracks the currently assigned job.
// Only one range is processed at a time per worker.
type ManagedWorker struct {
	pb.UnimplementedWorkerSearchServer

	search *worker.Server

	mu         sync.Mutex
	busy       bool
	currentJob string
}

func (w *ManagedWorker) CurrentJobID() string {
	w.mu.Lock()
	defer w.mu.Unlock()

	return w.currentJob
}

func (w *ManagedWorker) Search(
	req *pb.SearchRequest,
	stream pb.WorkerSearch_SearchServer,
) error {

	w.mu.Lock()

	if w.busy {
		w.mu.Unlock()

		return status.Error(
			codes.ResourceExhausted,
			"worker is already processing a range",
		)
	}

	w.busy = true
	w.currentJob = req.GetJobId()
	w.mu.Unlock()

	defer func() {
		w.mu.Lock()
		w.busy = false
		w.currentJob = ""
		w.mu.Unlock()
	}()

	return w.search.Search(req, stream)
}

func main() {

	workerID := flag.String(
		"id", "worker-1", "Unique worker ID",
	)

	listenAddr := flag.String(
		"listen", "127.0.0.1:50061",
		"Worker gRPC listening address",
	)

	coordinatorAddr := flag.String(
		"coordinator", "127.0.0.1:50052",
		"Coordinator gRPC address",
	)

	heartbeatInterval := flag.Duration(
		"heartbeat", 2*time.Second,
		"Heartbeat interval",
	)

	flag.Parse()

	if *workerID == "" ||
		*heartbeatInterval <= 0 {
		log.Fatal("invalid worker configuration")
	}

	ctx, stop := signal.NotifyContext(
		context.Background(),
		os.Interrupt,
		syscall.SIGTERM,
	)
	defer stop()

	// Start the worker's gRPC Search server.
	listener, err := net.Listen("tcp", *listenAddr)
	if err != nil {
		log.Fatalf("Cannot listen: %v", err)
	}

	managed := &ManagedWorker{
		search: worker.NewServer(*workerID),
	}

	grpcServer := grpc.NewServer()

	pb.RegisterWorkerSearchServer(
		grpcServer,
		managed,
	)

	go func() {
		if err := grpcServer.Serve(listener); err != nil {
			log.Printf("gRPC server stopped: %v", err)
			stop()
		}
	}()

	defer grpcServer.Stop()

	log.Printf(
		"Worker %s listening on %s",
		*workerID,
		*listenAddr,
	)

	// Connect to the coordinator.
	conn, err := grpc.NewClient(
		*coordinatorAddr,
		grpc.WithTransportCredentials(
			insecure.NewCredentials(),
		),
	)
	if err != nil {
		log.Fatalf("Coordinator connection: %v", err)
	}
	defer conn.Close()

	registry := pb.NewCoordinatorRegistryClient(conn)

	registered := false

	for {
		if ctx.Err() != nil {
			log.Printf("Worker %s shutting down", *workerID)
			return
		}

		callCtx, cancel := context.WithTimeout(
			ctx,
			1500*time.Millisecond,
		)

		if !registered {

			response, err := registry.RegisterWorker(
				callCtx,
				&pb.RegisterWorkerRequest{
					WorkerId:    *workerID,
					GrpcAddress: *listenAddr,
				},
			)

			if err != nil {
				log.Printf(
					"Worker %s: registration pending: %v",
					*workerID, err,
				)
			} else if !response.GetAccepted() {
				log.Printf(
					"Worker %s: registration rejected: %s",
					*workerID,
					response.GetMessage(),
				)
			} else {
				registered = true

				log.Printf(
					"Worker %s registered successfully",
					*workerID,
				)
			}

		} else {

			jobID := managed.CurrentJobID()

			response, err := registry.Heartbeat(
				callCtx,
				&pb.HeartbeatRequest{
					WorkerId:     *workerID,
					CurrentJobId: jobID,
				},
			)

			if err != nil || !response.GetAccepted() {
				registered = false

				log.Printf(
					"Worker %s: heartbeat failed; re-registering",
					*workerID,
				)
			} else {
				log.Printf(
					"Worker %s: heartbeat OK, job=%q",
					*workerID,
					jobID,
				)
			}
		}

		cancel()

		select {
		case <-ctx.Done():
			log.Printf(
				"Worker %s shutting down",
				*workerID,
			)
			return

		case <-time.After(*heartbeatInterval):
		}
	}
}
