package main

import (
	"context"
	"log"
	"net"
	"time"

	pb "example.com/ads-assignment1/part2-logviewer/proto"

	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

// Implementation of the LogViewer gRPC service.
type logServer struct {
	pb.UnimplementedLogViewerServiceServer
}

// Unary RPC: returns information about the server.
func (s *logServer) GetServerInfo(
	ctx context.Context,
	req *pb.ServerInfoRequest,
) (*pb.ServerInfoResponse, error) {

	log.Println("Unary request: GetServerInfo")

	return &pb.ServerInfoResponse{
		ServerName: "ADS Live Log Viewer",
		Status:     "RUNNING",
		Version:    "1.0",
	}, nil
}

// Server-streaming RPC: sends logs one by one.
func (s *logServer) StreamLogs(
	req *pb.StreamLogsRequest,
	stream pb.LogViewerService_StreamLogsServer,
) error {

	count := req.GetCount()

	if count < 1 || count > 50 {
		return status.Error(
			codes.InvalidArgument,
			"count must be between 1 and 50",
		)
	}

	log.Printf("Streaming started: %d messages", count)

	messages := []struct {
		level   string
		message string
	}{
		{"INFO", "Server started successfully"},
		{"INFO", "Client connected"},
		{"DEBUG", "Processing client request"},
		{"WARNING", "Simulated high memory usage"},
		{"INFO", "Request processing completed"},
	}

	for i := int32(0); i < count; i++ {

		// Stop if the client cancels the RPC.
		select {
		case <-stream.Context().Done():
			log.Println("Streaming cancelled by client")
			return stream.Context().Err()
		default:
		}

		msg := messages[int(i)%len(messages)]

		entry := &pb.LogEntry{
			Sequence:  i + 1,
			Timestamp: time.Now().Format(time.RFC3339),
			Level:     msg.level,
			Message:   msg.message,
		}

		// Send one log entry to the client.
		if err := stream.Send(entry); err != nil {
			log.Printf("Stream send error: %v", err)
			return err
		}

		log.Printf("Sent log %d/%d: %s",
			i+1, count, entry.Message)

		// Wait one second before sending the next log.
		if i < count-1 {
			select {
			case <-time.After(time.Second):
			case <-stream.Context().Done():
				log.Println("Streaming cancelled by client")
				return stream.Context().Err()
			}
		}
	}

	log.Println("Streaming completed successfully")
	return nil
}

func main() {

	listener, err := net.Listen("tcp", "127.0.0.1:50051")
	if err != nil {
		log.Fatalf("Failed to listen: %v", err)
	}

	grpcServer := grpc.NewServer()

	pb.RegisterLogViewerServiceServer(
		grpcServer,
		&logServer{},
	)

	log.Println("================================")
	log.Println("ADS Live Log Viewer Server")
	log.Println("Listening on 127.0.0.1:50051")
	log.Println("================================")

	if err := grpcServer.Serve(listener); err != nil {
		log.Fatalf("Failed to serve: %v", err)
	}
}
