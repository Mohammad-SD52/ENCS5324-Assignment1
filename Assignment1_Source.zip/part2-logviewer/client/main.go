package main

import (
	"context"
	"flag"
	"fmt"
	"io"
	"log"
	"time"

	pb "example.com/ads-assignment1/part2-logviewer/proto"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

func main() {
	// Command-line options
	mode := flag.String(
		"mode", "info", "RPC mode: info or stream",
	)
	count := flag.Int(
		"count", 5, "Number of log messages",
	)
	flag.Parse()

	// Connect to the local gRPC server
	conn, err := grpc.NewClient(
		"127.0.0.1:50051",
		grpc.WithTransportCredentials(
			insecure.NewCredentials(),
		),
	)
	if err != nil {
		log.Fatalf("Connection error: %v", err)
	}
	defer conn.Close()

	client := pb.NewLogViewerServiceClient(conn)

	switch *mode {

	case "info":
		// Unary RPC
		ctx, cancel := context.WithTimeout(
			context.Background(),
			5*time.Second,
		)
		defer cancel()

		response, err := client.GetServerInfo(
			ctx,
			&pb.ServerInfoRequest{},
		)
		if err != nil {
			log.Fatalf("Unary RPC failed: %v", err)
		}

		fmt.Println("===== UNARY RPC RESULT =====")
		fmt.Println("Server:", response.GetServerName())
		fmt.Println("Status:", response.GetStatus())
		fmt.Println("Version:", response.GetVersion())

	case "stream":
		// Server-streaming RPC
		ctx, cancel := context.WithTimeout(
			context.Background(),
			time.Duration(*count+5)*time.Second,
		)
		defer cancel()

		stream, err := client.StreamLogs(
			ctx,
			&pb.StreamLogsRequest{
				Count: int32(*count),
			},
		)
		if err != nil {
			log.Fatalf("Streaming RPC failed: %v", err)
		}

		fmt.Println("===== SERVER STREAMING =====")

		for {
			entry, err := stream.Recv()

			if err == io.EOF {
				fmt.Println("===== STREAM COMPLETED =====")
				break
			}

			if err != nil {
				log.Fatalf("Stream receive error: %v", err)
			}

			fmt.Printf(
				"[%d] %s | %-7s | %s\n",
				entry.GetSequence(),
				entry.GetTimestamp(),
				entry.GetLevel(),
				entry.GetMessage(),
			)
		}

	default:
		log.Fatalf("Unknown mode: %s", *mode)
	}
}
